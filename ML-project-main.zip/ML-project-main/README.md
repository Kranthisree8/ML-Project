# ML-project (Used car price prediction using Machine Learning)
Student ID: 700746583
Student name : Kranthisree(KXN65830)
